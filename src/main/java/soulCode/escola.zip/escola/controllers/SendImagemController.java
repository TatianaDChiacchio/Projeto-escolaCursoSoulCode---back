package soulCode.escola.controllers;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import soulCode.escola.models.Professor;
import soulCode.escola.repositorys.ProfessorRepository;
import soulCode.escola.services.ProfessorService;
import soulCode.escola.utils.FileUploadUtil;

@RestController
@RequestMapping("escola")
public class SendImagemController {
	
	@Autowired
	private ProfessorService professorService;
	
		
	@CrossOrigin
	@PostMapping("/send/{id_professor}")
    public ResponseEntity<String> receiveData(@PathVariable Integer id_professor,MultipartFile foto, @RequestParam("nome") String nome) {

		String fileName = nome;
        ///home/tatiana/Área de Trabalho/escolaFotos

		String uploadDir = "/home/tatiana/Downloads/imagens";
		String nomeCaminho = "c:" + uploadDir+"/"+nome;
		
		Professor professor = professorService.salvarFoto(id_professor, nomeCaminho);
		
		
		try {
			FileUploadUtil.saveFile(uploadDir, fileName, foto);
			System.out.println(uploadDir);
		} catch (Exception e) {
			System.out.println("O arquivo não foi salvo! " + e);
			//return "Error" + e;
		}
        
		System.out.println("Deu certo: " + nomeCaminho);
        return ResponseEntity.ok("Deu certo!" );
    }

}
