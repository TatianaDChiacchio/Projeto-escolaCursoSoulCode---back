package soulCode.escola.repositorys;

import org.springframework.data.jpa.repository.JpaRepository;

import soulCode.escola.models.Turma;

public interface TurmaRepository extends JpaRepository<Turma,Integer>{

}
