package soulCode.escola.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import soulCode.escola.models.Professor;
import soulCode.escola.models.Turma;
import soulCode.escola.repositorys.TurmaRepository;


@Service
public class TurmaService {

	@Autowired
	private TurmaRepository turmaRepository;
	
	@Lazy
	@Autowired
	private ProfessorService professorService;

	public List<Turma> mostrarTodasTurmas() {
		return turmaRepository.findAll();
	}

	public Turma buscarUmaTurma(Integer id_turma) {
		Optional<Turma> turma = turmaRepository.findById(id_turma);
		return turma.orElseThrow(() -> new soulCode.escola.services.exceptions.ObjectNotFoundException(
				"Objeto não cadastrado! O id procurado foi: " + id_turma));
	}
	
	
	

	public Turma cadastrarTurma(Integer id_professor, Turma turma) {
		// é uma forma de segurança para não setarmos o id
		turma.setId_turma(null);
		if (id_professor != null) {
			Professor professor = professorService.mostrarUmProfessor(id_professor);
			turma.setProfessor(professor);
			turma.setTemProfessor(true);
		}else {
			turma.setTemProfessor(false);
		}
		
		return turmaRepository.save(turma);
	}

	public Turma editarTurma(Turma turma) {
		buscarUmaTurma(turma.getId_turma());
		return turmaRepository.save(turma);
	}

	public void deletarUmaTurma(Integer id_turma) {
		buscarUmaTurma(id_turma);
		try {
			turmaRepository.deleteById(id_turma);
		}catch(org.springframework.dao.DataIntegrityViolationException e) {
			throw new soulCode.escola.services.exceptions.DataIntegrityViolationException(
					"A turma não pode ser deletada! Possui alunos relacionados!");
		}
		
	}

}
