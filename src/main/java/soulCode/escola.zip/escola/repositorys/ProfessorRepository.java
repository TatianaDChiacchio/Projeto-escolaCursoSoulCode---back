package soulCode.escola.repositorys;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import soulCode.escola.models.Professor;

public interface ProfessorRepository extends JpaRepository<Professor, Integer>{
	
	@Query(value = "SELECT * FROM professor WHERE id_turma = :id_turma", nativeQuery = true)
	Professor fetchByTurma(Integer id_turma);

}
